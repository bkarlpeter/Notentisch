@echo off
REM Notentisch Complete Package Launcher
REM ===========================================

cd /d "%~dp0"

REM Start Notentisch server in background (no extra window)
start /B Notentisch.exe >nul 2>&1

REM Wait until the one-file EXE has unpacked and the server is reachable.
for /L %%I in (1,1,20) do (
    powershell -NoProfile -Command "try { $r = Invoke-WebRequest -UseBasicParsing -TimeoutSec 1 http://127.0.0.1:8000/board.html; if ($r.StatusCode -eq 200) { exit 0 } } catch {}; exit 1"
    if not errorlevel 1 goto server_ready
    timeout /t 1 /nobreak >nul
)

echo Notentisch server did not start on port 8000.
pause
exit /b 1

:server_ready
start "" "http://127.0.0.1:8000/board.html"
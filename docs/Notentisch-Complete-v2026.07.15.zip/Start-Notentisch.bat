@echo off
REM Notentisch Complete Package Launcher
REM ===========================================

cd /d "%~dp0"

REM Start Notentisch server
echo Starting Notentisch server...
start http://127.0.0.1:8000
Notentisch.exe

pause
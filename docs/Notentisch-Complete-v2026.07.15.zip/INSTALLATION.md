﻿# Notentisch Complete Package - Installation Guide

## What's included
- **Notentisch.exe**: Standalone note viewer (board.html)
- **Web assets**: HTML/CSS/JS for board/config views
- **Sample PDFs**: 0 example scores (available separately when not included)
- **Launcher script**: Quick start batch file

## Requirements
- Windows 7 or later

## Installation

1. Extract all files to a folder (e.g., C:\Notentisch)

2. Double-click **Start-Notentisch.bat**

## First Use

### For Note Viewing:
1. Run Start-Notentisch.bat
2. Browser opens automatically to http://127.0.0.1:8000/board.html
3. Displays the note board interface

## Troubleshooting

**"Notentisch.exe won't start"**
-> Check Windows Defender, may need to allow through firewall

**"Browser opens but page does not load"**
-> Ensure port 8000 is free and not blocked by another app.

## Support
For issues or questions, check the project repository.

---
Version: v2026.07.15
Generated: 2026-08-09 21:09:12
